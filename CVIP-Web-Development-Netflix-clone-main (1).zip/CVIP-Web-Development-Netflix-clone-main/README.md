# CVIP-Web-Development-Netflix-clone
I have made Netflix Clone app using html, css and Javascript.
